/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */

package namoosori.oops.radio.stage;

import java.util.ArrayList;
import java.util.List;

import namoosori.oops.radio.exception.NoChildException;
import namoosori.oops.radio.exception.NoRadioException;
import namoosori.oops.radio.player.Child;
import namoosori.oops.radio.player.Radio;
import namoosori.oops.util.TalkingAt;
import namoosori.oops.util.Narrator;

public class LivingRoom {
	//
	private List<Child> playingChildren; 
	private Radio radio; 

	private Narrator narrotor; 
	
	public LivingRoom() {
		//
		this.playingChildren = new ArrayList<Child>(); 
		this.narrotor = Narrator.newInstance("livingRoom", this, TalkingAt.Left); 
	}
	
	public void enter(Child child) {
		//
		narrotor.say(String.format("거실에 아이(%s)가 들어오는군.", child.getName()));
		this.playingChildren.add(child); 
	}
	
	public boolean existChild(String name) {
		// 
		for(Child child : playingChildren) {
			// 
			String childName = child.getName(); 
			if (childName.equals(name)) {
				return true; 
			}
		}
		
		return false; 
	}
	
	public Child findChild(String name) {
		//
		for(Child child : playingChildren) {
			// 
			String childName = child.getName(); 
			if (childName.equals(name)) {
				return child; 
			}
		}
		
		throw new NoChildException(name + "는 여기 없어요."); 
	}
	
	public void setUp(Radio radio) {
		//
		narrotor.say(String.format("거실에 라디오(%s)를 설치합니다.", radio.getName()));
		this.radio = radio;
	}
	
	public boolean containRadio() {
		// 
		if (radio != null) {
			return true; 
		}
		
		return false; 
	}
	
	public Radio findRadio() {
		//
		if (radio == null) {
			throw new NoRadioException("Radio가 없어요.");  
		}
		
		return radio; 
	}	
}