package namoo.nara.town.domain.entity;

import namoo.nara.share.domain.util.Identifiable;
import namoo.nara.share.domain.util.numeral36.Numeral36;

import java.util.List;

/**
 * Created by kchuh@nextree.co.kr on 2016. 2. 1..
 */
public class Citizen implements Identifiable {
    //
    private String usid;
    private String castellanId;
    private String metroId;
    private String name;
    private String email; // Unique in metro
    private long createTime;
    private List<Towner> towners;

    public Citizen() {
        //
    }

    protected Citizen(long sequence, String name, String metroId, String castellanId) {
        //
        this.castellanId = castellanId;
        this.metroId = metroId;
        this.name = name;
        this.createTime = System.currentTimeMillis();
        this.usid = initializeUsid(sequence);
    }

    public static Citizen newInstance(long sequence, String name, String metroId, String castellanId) {
        //
        Citizen citizen = new Citizen(sequence, name, metroId, castellanId);
        return citizen;
    }

    private String initializeUsid(long sequence) {
        //
        return metroId + "-" + Numeral36.getInstance().getStr36(sequence);
    }


    @Override
    public String getId() {
        return usid;
    }

    public void setUsid(String usid) {
        this.usid = usid;
    }

    public String getCastellanId() {
        return castellanId;
    }

    public void setCastellanId(String castellanId) {
        this.castellanId = castellanId;
    }

    public String getMetroId() {
        return metroId;
    }

    public void setMetroId(String metroId) {
        this.metroId = metroId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }

    public List<Towner> getTowners() {
        return towners;
    }

    public void setTowners(List<Towner> towners) {
        this.towners = towners;
    }
}
