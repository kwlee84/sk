package namoo.nara.town.domain.entity;

/**
 * Created by kchuh@nextree.co.kr on 2016. 3. 2..
 */
public enum NodePosition {

    /**
     * Just for organization chart root node
     */
    NodeRoot,

    OrgLeaf,

    OrgIntermediate,

    /**
     * Default town must be a organization root node
     */
    OrgRoot,

}
