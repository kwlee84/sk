package namoo.nara.town.domain.entity;

import namoo.nara.share.domain.util.Identifiable;

/**
 * Created by kchuh@nextree.co.kr on 2016. 1. 29..
 */
public class Town implements Identifiable {
    //
    private String usid;
    private String metroId;
    private String name;     // Unique in metro
    private String pathName; // Display town path name in organization chart. Default value is same with name.
    private long createTime;
    private TownRole townRole;

    public Town() {
        //
    }

    protected Town(TownRole townRole, String metroId, String name) {
        //
        this.townRole = townRole;
        this.metroId = metroId;
        this.name = name;
        this.pathName = name;
        this.createTime = System.currentTimeMillis();
    }

    public static Town newSubordinate(String metroId, String name) {
        //
        Town town = new Town(TownRole.ST, metroId, name);
        return town;
    }

    public static Town newHeadQuarter(String metroId, String name) {
        //
        Town town = new Town(TownRole.HQ, metroId, name);
        return town;
    }

    public static Town newControlCenter(String metroId, String name) {
        //
        Town town = new Town(TownRole.CC, metroId, name);
        return town;
    }

    @Override
    public String getId() {
        return usid;
    }

    public void setUsid(String usid) {
        this.usid = usid;
    }

    public String getMetroId() {
        return metroId;
    }

    public void setMetroId(String metroId) {
        this.metroId = metroId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPathName() {
        return pathName;
    }

    public void setPathName(String pathName) {
        this.pathName = pathName;
    }

    public long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }

    public TownRole getTownRole() {
        return townRole;
    }

    public void setTownRole(TownRole townRole) {
        this.townRole = townRole;
    }

}
