package namoo.nara.town.domain.entity.sequence;

import namoo.nara.share.domain.util.Identifiable;

/**
 * Created by kchuh@nextree.co.kr on 2016. 4. 16..
 */
public class CitizenSequence implements Identifiable {
    //
    private String metroId;
    private long sequence;

    protected CitizenSequence() {
        //
    }

    public static CitizenSequence newInstance(String metroId) {
        //
        CitizenSequence queue = new CitizenSequence();
        queue.setMetroId(metroId);
        queue.setSequence(0);
        return queue;
    }

    @Override
    public String getId() {
        return metroId;
    }

    public void setMetroId(String metroId) {
        this.metroId = metroId;
    }

    public long getSequence() {
        return sequence;
    }

    public void setSequence(long sequence) {
        this.sequence = sequence;
    }
}
