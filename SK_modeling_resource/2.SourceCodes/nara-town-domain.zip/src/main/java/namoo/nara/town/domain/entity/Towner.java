package namoo.nara.town.domain.entity;

import namoo.nara.share.domain.util.Identifiable;

/**
 * Created by kchuh@nextree.co.kr on 2016. 1. 29..
 */
public class Towner implements Identifiable {
    //
    private String usid;
    private String citizenId;
    private String townId;
    private long joinTime;
    private TownerRole townerRole;

    public Towner() {
        //
    }

    protected Towner(String citizenId, String townId) {
        //
        this.citizenId = citizenId;
        this.townId = townId;
        this.joinTime = System.currentTimeMillis();
    }

    public static Towner newTowner(String citizenId, String townId) {
        //
        Towner towner = new Towner(citizenId, townId);
        towner.setTownerRole(TownerRole.Towner);
        return towner;
    }

    public static Towner newHeadman(String citizenId, String townId) {
        //
        Towner towner = new Towner(citizenId, townId);
        towner.setTownerRole(TownerRole.Headman);
        return towner;
    }

    @Override
    public String getId() {
        return usid;
    }

    public void setUsid(String usid) {
        this.usid = usid;
    }

    public String getCitizenId() {
        return citizenId;
    }

    public void setCitizenId(String citizenId) {
        this.citizenId = citizenId;
    }

    public String getTownId() {
        return townId;
    }

    public void setTownId(String townId) {
        this.townId = townId;
    }

    public long getJoinTime() {
        return joinTime;
    }

    public void setJoinTime(long joinTime) {
        this.joinTime = joinTime;
    }

    public TownerRole getTownerRole() {
        return townerRole;
    }

    public void setTownerRole(TownerRole townerRole) {
        this.townerRole = townerRole;
    }
}
