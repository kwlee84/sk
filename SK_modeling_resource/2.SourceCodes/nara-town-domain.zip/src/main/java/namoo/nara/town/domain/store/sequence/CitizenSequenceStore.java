package namoo.nara.town.domain.store.sequence;


import namoo.nara.town.domain.entity.sequence.CitizenSequence;

/**
 * Created by kchuh@nextree.co.kr on 2016. 4. 16..
 */
public interface CitizenSequenceStore {
    //
    void create(CitizenSequence townSequenceQueue);
    long retrieveNext(String metroId);
}
