package namoo.nara.town.domain.entity;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by kchuh@nextree.co.kr on 2016. 2. 1..
 */
public class OrgNode {
    //
    private String targetTownId;
    private List<OrgNode> children;
    private NodePosition nodePosition;

    public OrgNode() {
        //
    }

    protected OrgNode(NodePosition nodePosition) {
        //
        this.nodePosition = nodePosition;
    }

    protected OrgNode(String targetTownId, NodePosition nodePosition) {
        //
        this.targetTownId = targetTownId;
        this.nodePosition = nodePosition;
    }

    public static OrgNode newInstance(NodePosition nodePosition) {
        //
        OrgNode orgNode = new OrgNode(nodePosition);
        return orgNode;
    }

    public static OrgNode newInstance(String targetTownId, NodePosition nodePosition) {
        //
        OrgNode orgNode = new OrgNode(targetTownId, nodePosition);
        return orgNode;
    }

    public String getTargetTownId() {
        return targetTownId;
    }

    public void setTargetTownId(String targetTownId) {
        this.targetTownId = targetTownId;
    }

    public List<OrgNode> getChildren() {
        return children;
    }

    public void setChildren(List<OrgNode> children) {
        this.children = children;
    }

    public void addChildNode(OrgNode orgNode) {
        if (this.children == null) this.children = new ArrayList<>();
        this.children.add(orgNode);
        // If parent node is not organization root
        // set as intermediate
        if (NodePosition.OrgLeaf.equals(nodePosition)) {
            nodePosition = NodePosition.OrgIntermediate;
        }
    }

    public void removeChildNode(String townId) {
        for(OrgNode orgNode : this.getChildren())
        {
            if(townId.equals(orgNode.getTargetTownId())) {
                this.getChildren().remove(orgNode);
                break;
            }
        }
    }

    public NodePosition getNodePosition() {
        return nodePosition;
    }

    public void setNodePosition(NodePosition nodePosition) {
        this.nodePosition = nodePosition;
    }

    public boolean isLeaf() {
        //
        if (NodePosition.OrgLeaf.equals(this.nodePosition)) return true;
        return false;
    }

    public boolean isOrgRoot() {
        //
        if (NodePosition.OrgRoot.equals(this.nodePosition)) return true;
        return false;
    }

    public boolean hasChildren() {
        //
        if (children != null && children.size() > 0) return true;
        return false;
    }

    public void filterNode(List<String> townIds){
        //
        List<OrgNode> removeNodes = new ArrayList<OrgNode>();

        for(OrgNode orgNode : this.getChildren()) {
            if(townIds.contains(orgNode.getTargetTownId())) {
                if(orgNode.getChildren() != null) {
                    orgNode.filterNode(townIds);
                }
            } else {
                removeNodes.add(orgNode);
            }
        }

        for(OrgNode removeOrgNode : removeNodes) {
            this.getChildren().remove(removeOrgNode);
        }
    }

}
