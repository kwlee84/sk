package namoo.nara.town.domain.logic;

import namoo.nara.share.domain.util.numeral36.Numeral36;

/**
 * Created by kchuh@nextree.co.kr on 2016. 4. 20..
 */
public class TownIdPolicy {
    //
    private static final int TownIdFormatLength = 3;

    public static String initCitizenId(String metroId, long citizenSequence) {
        //
        return metroId + "-" + Numeral36.getInstance().getStr36(citizenSequence);
    }

    public static String initTownId(String metroId, long townSequence) {
        //
        return metroId + "-" + Numeral36.getInstance().getStr36(townSequence, TownIdFormatLength);
    }

    public static String initTownerId(String townId, long townerSequence) {
        //
        return townId + "-" + Numeral36.getInstance().getStr36(townerSequence);
    }
}
