package namoo.nara.town.domain.service;

import namoo.nara.town.domain.entity.Citizen;

import java.util.List;

/**
 * Created by kchuh@nextree.co.kr on 2016. 4. 14..
 */
public interface CitizenService {
    //
    String registerCitizen(String metroId, String castleId, String name, String email);
    Citizen findCitizen(String id);
    Citizen findCitizenByEmail(String metroId, String email);
    Citizen findCitizenByCastellanId(String metroId, String castellanId);

    List<Citizen> findCitizensByMetroId(String metroId);
    List<Citizen> findCitizensByEmailLike(String metroId, String email);
}
