package namoo.nara.town.domain.entity;

/**
 * Created by kchuh@nextree.co.kr on 2016. 3. 2..
 */
public enum TownRole {
    //
    /**
     * Headquarter
     */
    HQ,

    /**
     * Subordinate Town
     */
    ST,

    /**
     * Control Center
     */
    CC
}
