package namoo.nara.town.domain.entity;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by kchuh@nextree.co.kr on 2016. 2. 1..
 */
public class OrgChart {
    //
    private String metroId;
    private OrgNode rootNode;

    public OrgChart() {
        //
    }

    protected OrgChart(String metroId, OrgNode rootNode) {
        //
        this.metroId = metroId;
        this.rootNode = rootNode;
    }

    public static OrgChart newInstance(String metroId, OrgNode rootNode) {
        //
        OrgChart orgChart = new OrgChart(metroId, rootNode);
        return orgChart;
    }

    public OrgNode findDefaultTownNode() {
        //
        List<OrgNode> childNodes = rootNode.getChildren();
        for(OrgNode child : childNodes) {
            if (NodePosition.OrgRoot.equals(child.getNodePosition())) {
                return child;
            }
        }
        return null;
    }

    public OrgNode findNode(String townId) {
        //
        return findNode(townId, rootNode);
    }

    private OrgNode findNode(String townId, OrgNode orgNode) {
        //
        if (townId.equals(orgNode.getTargetTownId())) {
            return orgNode;
        }
        else {
            List<OrgNode> children = orgNode.getChildren();
            if (children != null) {
                for(OrgNode child : children) {
                    OrgNode found = findNode(townId, child);
                    if (found != null) {
                        return found;
                    }
                }
            }
        }
        return null;
    }

    public String getMetroId() {
        return metroId;
    }

    public void setMetroId(String metroId) {
        this.metroId = metroId;
    }

    public OrgNode getRootNode() {
        return rootNode;
    }

    public void setRootNode(OrgNode rootNode) {
        this.rootNode = rootNode;
    }

    public List<String> findAllTownIds() {
        //
        List<String> ids = new ArrayList<>();
        buildTownIds(rootNode.getChildren(), ids);
        return ids;
    }

    private void buildTownIds(List<OrgNode> nodes, List<String> ids) {
        //
        if (nodes == null) return;
        for(OrgNode node : nodes) {
            ids.add(node.getTargetTownId());
            buildTownIds(node.getChildren(), ids);
        }
    }

    public void filterOrgChart(List<String> townIds) {
        //
       this.getRootNode().filterNode(townIds);
    }
}
