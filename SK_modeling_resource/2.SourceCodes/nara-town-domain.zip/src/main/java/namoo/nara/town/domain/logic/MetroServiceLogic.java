package namoo.nara.town.domain.logic;

import namoo.nara.town.domain.entity.Metro;
import namoo.nara.town.domain.entity.sequence.CitizenSequence;
import namoo.nara.town.domain.entity.sequence.TownSequence;
import namoo.nara.town.domain.service.MetroService;
import namoo.nara.town.domain.store.*;
import namoo.nara.town.domain.store.sequence.CitizenSequenceStore;
import namoo.nara.town.domain.store.sequence.TownSequenceStore;
import namoo.nara.town.domain.store.sequence.TownerSequenceStore;

import java.util.List;

/**
 * Created by kchuh@nextree.co.kr on 2016. 4. 14..
 */
public class MetroServiceLogic implements MetroService {
    //
    private MetroStore metroStore;

    private CitizenSequenceStore citizenSequenceStore;
    private TownSequenceStore townSequenceStore;
    private TownerSequenceStore townerSequenceStore;

    public MetroServiceLogic(TownStoreLycler storeLycler) {
        //
        metroStore = storeLycler.requestMetroStore();

        citizenSequenceStore = storeLycler.requestCitizenSequenceQueueStore();
        townSequenceStore = storeLycler.requestTownSequenceQueueStore();
        townerSequenceStore = storeLycler.requestTownerSequenceQueueStore();
    }

    @Override
    public void registerMetro(String metroId, String metroName) {
        //
        // Create metro.
        Metro metro = Metro.newInstance(metroId, metroName);
        metroStore.create(metro);

        // Create citizen sequence.
        citizenSequenceStore.create(CitizenSequence.newInstance(metroId));
        // Create town sequence.
        townSequenceStore.create(TownSequence.newInstance(metroId));
    }

    @Override
    public Metro findMetro(String metroId) {
        //
        return metroStore.retrieve(metroId);
    }

    @Override
    public Metro findMetroByName(String name) {
        //
        return metroStore.retrieveByName(name);
    }

    @Override
    public void modifyMetroName(String metroId, String metroName) {
        //
        Metro metro = metroStore.retrieve(metroId);
        metro.setName(metroName);
        metroStore.update(metro);
    }

    @Override
    public List<Metro> findMetros() {
        return metroStore.retrieveAll();
    }

    @Override
    public List<Metro> findMetrosByNameLike(String metroName) {
        return metroStore.retrieveByNameLike(metroName);
    }
}
