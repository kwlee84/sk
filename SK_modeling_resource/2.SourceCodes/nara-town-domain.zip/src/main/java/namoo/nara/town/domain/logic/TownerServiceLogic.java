package namoo.nara.town.domain.logic;

import namoo.nara.town.domain.entity.Towner;
import namoo.nara.town.domain.entity.TownerRole;
import namoo.nara.town.domain.service.TownerService;
import namoo.nara.town.domain.store.TownStoreLycler;
import namoo.nara.town.domain.store.TownerStore;
import namoo.nara.town.domain.store.sequence.TownerSequenceStore;

import java.util.List;

/**
 * Created by kchuh@nextree.co.kr on 2016. 4. 14..
 */
public class TownerServiceLogic implements TownerService {
    //
    private TownerStore townerStore;

    private TownerSequenceStore townerSequenceStore;

    public TownerServiceLogic(TownStoreLycler storeLycler) {
        //
        townerStore = storeLycler.requestTownerStore();
        townerSequenceStore = storeLycler.requestTownerSequenceQueueStore();
    }

    @Override
    public String registerTowner(String citizenId, String townId, TownerRole townerRole) {
        //
        Towner towner = null;
        if(TownerRole.Headman.equals(townerRole)) {
            towner = Towner.newHeadman(citizenId, townId);
        } else {
            towner = Towner.newTowner(citizenId, townId);
        }
        long sequence = townerSequenceStore.retrieveNext(townId);
        towner.setUsid(TownIdPolicy.initTownerId(townId, sequence));
        townerStore.create(towner);
        return towner.getId();
    }

    @Override
    public Towner findTowner(String townerId) {
        return townerStore.retrieveTowner(townerId);
    }

    @Override
    public List<Towner> findTowners(String townId) {
        //
        return townerStore.retrieveByTownId(townId);
    }

    @Override
    public List<Towner> findTownersByCitizenId(String citizenId) {
        //
        return townerStore.retrieveTownersByCitizenId(citizenId);
    }

    @Override
    public Towner findJoinedTowner(String citizenId, String townId) {
        //
        return townerStore.retrieveByCitizenIdAndTownId(citizenId, townId);
    }

    @Override
    public void removeTowner(String townerId) {
        //
        townerStore.delete(townerId);
    }
}
