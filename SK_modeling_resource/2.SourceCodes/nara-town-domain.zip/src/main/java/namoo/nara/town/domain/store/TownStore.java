package namoo.nara.town.domain.store;

import namoo.nara.town.domain.entity.Town;
import namoo.nara.town.domain.entity.TownRole;

import java.util.List;

/**
 * Created by kchuh@nextree.co.kr on 2016. 1. 29..
 */
public interface TownStore {
    //
    void create(Town town);
    Town retrieve(String id);
    Town retrieveByTownRole(String metroId, TownRole townRole);
    Town retrieveByMetroIdAndName(String metroId, String name);
    List<Town> retrieveByIds(List<String> ids);

    void update(Town town);
    void delete(String id);
}
