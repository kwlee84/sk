package namoo.nara.town.domain.proxy;

/**
 * Created by kchuh@nextree.co.kr on 2016. 3. 18..
 */
public interface CastleProxy {
    //

}
