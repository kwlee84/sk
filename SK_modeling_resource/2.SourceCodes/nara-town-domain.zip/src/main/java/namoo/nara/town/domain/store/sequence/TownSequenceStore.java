package namoo.nara.town.domain.store.sequence;

import namoo.nara.town.domain.entity.sequence.TownSequence;

/**
 * Created by kchuh@nextree.co.kr on 2016. 4. 16..
 */
public interface TownSequenceStore {
    //
    void create(TownSequence townSequence);
    long retrieveNext(String metroId);
}
