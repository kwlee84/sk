package namoo.nara.town.domain.store.sequence;

import namoo.nara.town.domain.entity.sequence.TownerSequence;

/**
 * Created by kchuh@nextree.co.kr on 2016. 4. 16..
 */
public interface TownerSequenceStore {
    //
    void create(TownerSequence townerSequenceQueue);
    long retrieveNext(String townId);
}
