package namoo.nara.town.domain.logic;

import namoo.nara.town.domain.entity.*;
import namoo.nara.town.domain.entity.sequence.TownerSequence;
import namoo.nara.town.domain.service.TownService;
import namoo.nara.town.domain.store.MetroStore;
import namoo.nara.town.domain.store.OrgChartStore;
import namoo.nara.town.domain.store.TownStore;
import namoo.nara.town.domain.store.TownStoreLycler;
import namoo.nara.town.domain.store.sequence.TownSequenceStore;
import namoo.nara.town.domain.store.sequence.TownerSequenceStore;

import java.util.List;

/**
 * Created by kchuh@nextree.co.kr on 2016. 1. 29..
 */
public class TownServiceLogic implements TownService {
    //
    private MetroStore metroStore;
    private TownStore townStore;
    private OrgChartStore orgChartStore;

    private TownSequenceStore townSequenceStore;
    private TownerSequenceStore townerSequenceStore;


    public TownServiceLogic(TownStoreLycler townStoreLycler) {
        //
        metroStore = townStoreLycler.requestMetroStore();
        townStore = townStoreLycler.requestTownStore();
        orgChartStore = townStoreLycler.requestOrgChartStore();
        townSequenceStore = townStoreLycler.requestTownSequenceQueueStore();
        townerSequenceStore = townStoreLycler.requestTownerSequenceQueueStore();
    }

    @Override
    public String registerControlCenter(String metroId) {
        //
        Metro metro = metroStore.retrieve(metroId);
        String townName = metro.getName() + "-CC";
        Town town = Town.newControlCenter(metroId, townName);

        return createTown(town);
    }

    @Override
    public String registerHeadQuarter(String metroId, String parentTownId) {
        //
        Town parentTown = townStore.retrieve(parentTownId);
        String townName = parentTown.getName() + "-HQ";
        Town town = Town.newHeadQuarter(metroId, townName);

        return createTown(town);
    }

    @Override
    public String registerDefaultTown(String metroId) {
        //
        Metro metro = metroStore.retrieve(metroId);
        String townName = metro.getName();
        Town town = Town.newSubordinate(metroId, townName);

        return createTown(town);
    }

    @Override
    public String registerSubordinateTown(String metroId, String townName, String parentTownId) {
        //
        // Create town.
        Town town = Town.newSubordinate(metroId, townName);
        return createTown(town);
    }

    private String createTown(Town town) {
        //
        String metroId = town.getMetroId();
        long sequence = townSequenceStore.retrieveNext(metroId);
        town.setUsid(TownIdPolicy.initTownId(metroId, sequence));

        townStore.create(town);
        String townId = town.getId();

        // Create towner sequence queue.
        townerSequenceStore.create(TownerSequence.newInstance(townId));
        return townId;
    }

    @Override
    public Town findTown(String id) {
        //
        return townStore.retrieve(id);
    }

    @Override
    public Town findTownByName(String metroId, String townName) {
        //
        return townStore.retrieveByMetroIdAndName(metroId, townName);
    }

    @Override
    public Town findDefaultTown(String metroId) {
        //
        OrgChart orgChart = orgChartStore.retrieve(metroId);
        OrgNode defaultTownNode = orgChart.findDefaultTownNode();
        return townStore.retrieve(defaultTownNode.getTargetTownId());
    }

    @Override
    public Town findControlCenter(String metroId) {
        //
        return townStore.retrieveByTownRole(metroId, TownRole.CC);
    }

    @Override
    public List<Town> findTowns(List<String> ids) {
        //
        return townStore.retrieveByIds(ids);
    }

    @Override
    public void modifyTownName(String townId, String townName, String pathName) {
        Town town = townStore.retrieve(townId);
        town.setName(townName);
        if(pathName != null && !pathName.isEmpty()) {
            town.setPathName(pathName);
        }
        townStore.update(town);
    }

    @Override
    public void removeTown(String id) {
        townStore.delete(id);
    }
}
