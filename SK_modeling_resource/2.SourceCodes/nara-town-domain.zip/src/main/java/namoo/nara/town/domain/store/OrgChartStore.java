package namoo.nara.town.domain.store;

import namoo.nara.town.domain.entity.OrgChart;

/**
 * Created by kchuh@nextree.co.kr on 2016. 2. 2..
 */
public interface OrgChartStore {
    //
    void create(OrgChart orgChart);
    void update(OrgChart orgChart);
    OrgChart retrieve(String metroId);
}
