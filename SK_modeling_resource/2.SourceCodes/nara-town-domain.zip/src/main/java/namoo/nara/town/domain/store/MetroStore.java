package namoo.nara.town.domain.store;

import namoo.nara.town.domain.entity.Metro;

import java.util.List;

/**
 * Created by kchuh@nextree.co.kr on 2016. 2. 2..
 */
public interface MetroStore {
    //
    void create(Metro metro);
    Metro retrieve(String id);
    void update(Metro metro);
    Metro retrieveByName(String name);
    List<Metro> retrieveAll();
    List<Metro> retrieveByNameLike(String name);
}
