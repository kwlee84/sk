package namoo.nara.town.domain.service;

import namoo.nara.town.domain.entity.OrgChart;

/**
 * Created by kchuh@nextree.co.kr on 2016. 4. 15..
 */
public interface OrgChartService {
    //
    void registerOrgChart(String metroId, String ccTownId, String defaultTownId);
    OrgChart findOrgChart(String metroId);
    void modifyOrgChart(OrgChart orgChart);
}
