package namoo.nara.town.domain.service;

import namoo.nara.town.domain.entity.Towner;
import namoo.nara.town.domain.entity.TownerRole;

import java.util.List;

/**
 * Created by kchuh@nextree.co.kr on 2016. 4. 14..
 */
public interface TownerService {
    //
    String registerTowner(String citizenId, String townId, TownerRole townerRole);
    Towner findTowner(String townerId);
    List<Towner> findTowners(String townId);
    List<Towner> findTownersByCitizenId(String citizenId);
    Towner findJoinedTowner(String citizenId, String townId);
    void removeTowner(String townerId);
}
