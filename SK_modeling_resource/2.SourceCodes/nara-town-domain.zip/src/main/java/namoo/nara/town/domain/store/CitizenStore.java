package namoo.nara.town.domain.store;

import namoo.nara.town.domain.entity.Citizen;

import java.util.List;

/**
 * Created by kchuh@nextree.co.kr on 2016. 2. 2..
 */
public interface CitizenStore {
    //
    void create(Citizen citizen);
    List<Citizen> retrieveByMetroId(String metroId);
    Citizen retrieve(String id);
    Citizen retrieveByMetroIdAndEmail(String metroOid, String email);

    List<Citizen> retrieveByMetroIdAndEmailLike(String metroOid, String email);
    Citizen retrieveByMetroIdAndCastellanId(String metroId, String castellanId);
}
