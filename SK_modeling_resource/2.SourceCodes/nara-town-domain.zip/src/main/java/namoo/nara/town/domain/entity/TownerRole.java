package namoo.nara.town.domain.entity;

/**
 * Created by kchuh@nextree.co.kr on 2016. 3. 2..
 */
public enum TownerRole {
    //
    Headman,
    Towner,
}
