package namoo.nara.town.domain.store;

import namoo.nara.town.domain.store.sequence.CitizenSequenceStore;
import namoo.nara.town.domain.store.sequence.TownSequenceStore;
import namoo.nara.town.domain.store.sequence.TownerSequenceStore;

/**
 * Created by kchuh@nextree.co.kr on 2016. 3. 30..
 */
public interface TownStoreLycler {
    //
    CitizenStore requestCitizenStore();
    MetroStore requestMetroStore();
    OrgChartStore requestOrgChartStore();
    TownerStore requestTownerStore();
    TownStore requestTownStore();

    CitizenSequenceStore requestCitizenSequenceQueueStore();
    TownSequenceStore requestTownSequenceQueueStore();
    TownerSequenceStore requestTownerSequenceQueueStore();
}
