package namoo.nara.town.domain.service;

/**
 * Created by kchuh@nextree.co.kr on 2016. 3. 31..
 */
public interface TownServiceLycler {
    //
    MetroService requestMetroService();
    CitizenService requestCitizenService();
    TownService requestTownService();
    TownerService requestTownerService();
    OrgChartService requestOrgChartService();
}
