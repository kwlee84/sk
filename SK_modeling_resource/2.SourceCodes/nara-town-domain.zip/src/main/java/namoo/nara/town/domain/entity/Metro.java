package namoo.nara.town.domain.entity;

import namoo.nara.share.domain.util.Identifiable;

/**
 * Created by kchuh@nextree.co.kr on 2016. 2. 1..
 */
public class Metro implements Identifiable {
    //
    private String usid;
    private String name;
    private long createTime;

    public Metro() {
        //
    }

    protected Metro(String usid, String name) {
        //
        this.usid = usid;
        this.name = name;
        this.createTime = System.currentTimeMillis();
    }

    public static Metro newInstance(String usid, String name) {
        //
        Metro metro = new Metro(usid, name);
        return metro;
    }

    @Override
    public String getId() {
        return usid;
    }

    public void setUsid(String usid) {
        this.usid = usid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }

}
