package namoo.nara.town.domain.store;

import namoo.nara.town.domain.entity.Towner;

import java.util.List;

/**
 * Created by kchuh@nextree.co.kr on 2016. 2. 2..
 */
public interface TownerStore {
    //
    void create(Towner towner);
    Towner retrieveTowner(String townerId);
    List<Towner> retrieveByTownId(String townId);
    List<Towner> retrieveTownersByCitizenId(String citizenId);
    Towner retrieveByCitizenIdAndTownId(String citizenId, String townId);
    void delete(String townerId);
}
