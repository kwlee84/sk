package namoo.nara.town.domain.service;

import namoo.nara.town.domain.entity.Metro;

import java.util.List;

/**
 * Created by kchuh@nextree.co.kr on 2016. 4. 14..
 */
public interface MetroService {
    //
    void registerMetro(String metroId, String metroName);
    Metro findMetro(String metroId);
    Metro findMetroByName(String metroName);
    void modifyMetroName(String metroId, String metroName);
    List<Metro> findMetros();
    List<Metro> findMetrosByNameLike(String metroName);
}
