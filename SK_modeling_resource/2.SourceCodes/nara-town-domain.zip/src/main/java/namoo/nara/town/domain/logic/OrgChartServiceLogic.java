package namoo.nara.town.domain.logic;

import namoo.nara.town.domain.entity.NodePosition;
import namoo.nara.town.domain.entity.OrgChart;
import namoo.nara.town.domain.entity.OrgNode;
import namoo.nara.town.domain.service.OrgChartService;
import namoo.nara.town.domain.store.OrgChartStore;
import namoo.nara.town.domain.store.TownStore;
import namoo.nara.town.domain.store.TownStoreLycler;

/**
 * Created by kchuh@nextree.co.kr on 2016. 4. 15..
 */
public class OrgChartServiceLogic implements OrgChartService {
    //
    private OrgChartStore orgChartStore;
    private TownStore townStore;

    public OrgChartServiceLogic(TownStoreLycler storeLycler) {
        //
        orgChartStore = storeLycler.requestOrgChartStore();
        townStore = storeLycler.requestTownStore();
    }

    @Override
    public void registerOrgChart(String metroId, String ccTownId, String defaultTownId) {
        //
        OrgNode rootNode = OrgNode.newInstance(NodePosition.NodeRoot);
        OrgNode ccTownNode = OrgNode.newInstance(ccTownId, NodePosition.OrgLeaf);
        OrgNode defaultTownNode = OrgNode.newInstance(defaultTownId, NodePosition.OrgRoot);

        rootNode.addChildNode(defaultTownNode);
        rootNode.addChildNode(ccTownNode);
        OrgChart orgChart = OrgChart.newInstance(metroId, rootNode);
        orgChartStore.create(orgChart);
    }

    @Override
    public void modifyOrgChart(OrgChart orgChart) {
        //
        orgChartStore.update(orgChart);
    }

    @Override
    public OrgChart findOrgChart(String metroId) {
        //
        return orgChartStore.retrieve(metroId);
    }
}
