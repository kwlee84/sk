package namoo.nara.town.domain.logic;

import namoo.nara.town.domain.entity.Citizen;
import namoo.nara.town.domain.service.CitizenService;
import namoo.nara.town.domain.store.CitizenStore;
import namoo.nara.town.domain.store.TownStoreLycler;
import namoo.nara.town.domain.store.sequence.CitizenSequenceStore;

import java.util.List;

/**
 * Created by kchuh@nextree.co.kr on 2016. 4. 14..
 */
public class CitizenServiceLogic implements CitizenService {
    //
    private CitizenStore citizenStore;
    private CitizenSequenceStore citizenSequenceStore;

    public CitizenServiceLogic(TownStoreLycler storeLycler) {
        //
        citizenStore = storeLycler.requestCitizenStore();
        citizenSequenceStore = storeLycler.requestCitizenSequenceQueueStore();
    }

    @Override
    public String registerCitizen(String metroId, String castleId, String name, String email) {
        //
        long sequence = citizenSequenceStore.retrieveNext(metroId);
        String citizenId = TownIdPolicy.initCitizenId(metroId, sequence);
        Citizen citizen = Citizen.newInstance(sequence, name, metroId, castleId);
        citizen.setUsid(citizenId);
        citizen.setEmail(email);
        citizenStore.create(citizen);
        return citizen.getId();
    }

    @Override
    public Citizen findCitizen(String id) {
        //
        return citizenStore.retrieve(id);
    }

    @Override
    public Citizen findCitizenByEmail(String metroId, String email) {
        //
        return citizenStore.retrieveByMetroIdAndEmail(metroId, email);
    }

    @Override
    public List<Citizen> findCitizensByMetroId(String metroId) {
        //
        return citizenStore.retrieveByMetroId(metroId);
    }

    @Override
    public List<Citizen> findCitizensByEmailLike(String metroId, String email) {
        return citizenStore.retrieveByMetroIdAndEmailLike(metroId, email);
    }

    @Override
    public Citizen findCitizenByCastellanId(String metroId, String castellanId) {
        return citizenStore.retrieveByMetroIdAndCastellanId(metroId, castellanId);
    }
}
