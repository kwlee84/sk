package namoo.nara.town.domain.service;

import namoo.nara.town.domain.entity.Town;

import java.util.List;

/**
 * Created by kchuh@nextree.co.kr on 2016. 1. 29..
 */
public interface TownService {
    //
    String registerControlCenter(String metroId);
    String registerDefaultTown(String metroId);
    String registerSubordinateTown(String metroId, String townName, String parentTownId);
    String registerHeadQuarter(String metroId, String parentTownId);
    Town findTown(String id);
    Town findTownByName(String metroId, String townName);
    Town findDefaultTown(String metroId);
    Town findControlCenter(String metroId);
    List<Town> findTowns(List<String> ids);
    void modifyTownName(String townId, String townName, String pathName);
    void removeTown(String id);
}
