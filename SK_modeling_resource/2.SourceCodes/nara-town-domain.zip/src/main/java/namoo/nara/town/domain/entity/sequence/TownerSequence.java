package namoo.nara.town.domain.entity.sequence;

import namoo.nara.share.domain.util.Identifiable;

/**
 * Created by kchuh@nextree.co.kr on 2016. 4. 16..
 */
public class TownerSequence implements Identifiable {
    //
    private String townId;
    private long sequence;

    protected TownerSequence() {
        //
    }

    public static TownerSequence newInstance(String townId) {
        //
        TownerSequence queue = new TownerSequence();
        queue.setTownId(townId);
        queue.setSequence(0);
        return queue;
    }

    @Override
    public String getId() {
        return townId;
    }

    public void setTownId(String townId) {
        this.townId = townId;
    }

    public long getSequence() {
        return sequence;
    }

    public void setSequence(long sequence) {
        this.sequence = sequence;
    }
}
