/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */

package namoosori.oops.ascii.step01;

public class AsciiCode {
	//
	public static final int ControlIndex = 32; 
	public static final int MaxIndex = 127; 
	
	private byte index; 
	private String code; 
	private boolean controlChar; 
	
	public AsciiCode(int index, String code) {
		// 
		if (index > MaxIndex) {
			throw new RuntimeException("Index shoud be under or equals " + MaxIndex); 
		}
		
		this.index = (byte)index; 
		this.code = code; 
		
		if (index < ControlIndex || index == MaxIndex) {
			this.controlChar = true; 
		} else {
			this.controlChar = false; 
		}
	}
	
	public int getIndex() {
		return (int)index;
	}
	
	public String getCode() {
		return code;
	}

	public boolean isControlChar() {
		return controlChar;
	}
}