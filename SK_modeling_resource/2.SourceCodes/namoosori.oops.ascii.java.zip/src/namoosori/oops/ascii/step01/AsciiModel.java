/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */

package namoosori.oops.ascii.step01;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class AsciiModel {
	//
	private static final String ControlChars = "NULL,SOH,STX,ETX,EOT,ENQ,ACK,BEL,BS,HT,LF,VT,FF,CR,SO,SI,DLE,DC1,SC2,SC3,SC4,NAK,SYN,ETB,CAN,EM,SUB,ESC,FS,GS,RS,US,SP,DEL"; 
	private List<AsciiCode> asciiCodes; 
	
	public AsciiModel() {
		//
		this.asciiCodes = new ArrayList<>(); 
		this.init(); 
	}

	public AsciiCode requestCode(int index) {
		// 
		return asciiCodes.get(index); 
	}
	
	public int countCode() {
		return asciiCodes.size(); 
	}
	
	private void init() {
		// 
		StringTokenizer st = new StringTokenizer(ControlChars, ","); 
		
		for(int i=0; i <= AsciiCode.ControlIndex; i++) {
			asciiCodes.add(new AsciiCode(i, st.nextToken())); 
		}
		
		for(int i = (AsciiCode.ControlIndex+1); i<(AsciiCode.MaxIndex); i++) {
			asciiCodes.add(new AsciiCode(i, String.valueOf((char)i))); 
		}
		
		asciiCodes.add(new AsciiCode(AsciiCode.MaxIndex, st.nextToken())); 
	}
}