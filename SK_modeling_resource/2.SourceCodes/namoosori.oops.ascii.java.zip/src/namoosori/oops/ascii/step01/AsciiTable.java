/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */

package namoosori.oops.ascii.step01;

public class AsciiTable {
	//
	private AsciiModel model; 
	
	public AsciiTable() {
		// 
		this.model = new AsciiModel(); 
	}
	
	public void show() {
		//
		int count = model.countCode(); 
		System.out.println("Index   Char");
		System.out.println("............");

		for(int index=0; index<count; index++) {
			// 
			AsciiCode asciiCode = model.requestCode(index); 
			System.out.println(
					String.format("%03d  %s", asciiCode.getIndex(), asciiCode.getCode()));
		}
	}
}