/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */

package namoosori.oops.ascii.step04;

import java.util.HashMap;
import java.util.Map;

public class AsciiColumn {
	// 
	private int rowCount;
	private int columnIndex; 
	private String header; 
	private Map<Integer,String> asciiCodeMap; 
	
	public AsciiColumn(int columnIndex, int rowCount) {
		// 
		this.rowCount = rowCount; 
		this.columnIndex = columnIndex; 
		this.asciiCodeMap = new HashMap<>(); 
	}
	
	public String toString() {
		// 
		StringBuilder builder = new StringBuilder(); 
		
		builder.append("rowCount:").append(rowCount);
		builder.append(", columnIndex:").append(columnIndex);
		builder.append(", header:").append(header);
		builder.append(", asciiCodeMap:").append(asciiCodeMap.toString());
		
		return builder.toString(); 
	}
	
	public void initWith(AsciiModel model, AsciiCodeStyle codeStyle) {
		// 
		int offset = columnIndex * rowCount; 
		this.header = codeStyle.getHeader(); 

		for(int i=0; i<rowCount; i++) {
			if (offset >= AsciiCode.MaxIntValue) {
				asciiCodeMap.put(offset, codeStyle.formatForNone()); 
				offset++; 
				continue; 
			}

			AsciiCode asciiCode = model.requestCode(offset); 
			asciiCodeMap.put(offset, codeStyle.format(asciiCode)); 
			offset++; 
		}
	}
	
	public String getHeader() {
		//
		return header; 
	}
	
	public String getAsciiStrOf(int intValue) {
		//
		return asciiCodeMap.get(intValue); 
	}
}
