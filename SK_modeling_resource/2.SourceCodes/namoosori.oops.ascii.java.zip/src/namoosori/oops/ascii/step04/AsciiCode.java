/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */

package namoosori.oops.ascii.step04;

public class AsciiCode {
	//
	public static final int ControlIntValue = 32; 
	public static final int MaxIntValue = 127; 
	public static final int MaxCodeLenght = 4; 
	
	private byte intValue; 
	private String code; 
	private boolean controlChar; 
	
	public AsciiCode(int index, String code) {
		// 
		if (index > MaxIntValue) {
			throw new RuntimeException("Index shoud be under " + MaxIntValue); 
		}
		
		this.intValue = (byte)index; 
		this.code = code; 
		
		if (index < ControlIntValue || index == MaxIntValue) {
			this.controlChar = true; 
		} else {
			this.controlChar = false; 
		}
	}
	
	public int getIntValue() {
		return (int)intValue;
	}

	public String getIntValueAsStr() {
		// 
		return String.format("%03d", intValue); 
	}
	
	public String getIntValueAsBinaryStr() {
		// 
		String binaryStr = Integer.toBinaryString(intValue); 
		
		StringBuilder builder = new StringBuilder(); 
		for(int i=0; i<(8-binaryStr.length()); i++) {
			builder.append("0"); 
		}
		builder.append(binaryStr); 
		
		return builder.toString(); 
	}
	
	public String getIntValueAsOctalStr() {
		//
		String octalStr = Integer.toOctalString(intValue); 
		
		StringBuilder builder = new StringBuilder(); 
		for(int i=0; i<(3-octalStr.length()); i++) {
			builder.append("0"); 
		}
		builder.append(octalStr); 
		
		return builder.toString(); 
	}
	
	public String getIntValueAsHexStr() {
		//
		String hexStr = Integer.toHexString(intValue); 
		
		StringBuilder builder = new StringBuilder(); 
		builder.append("0X"); 
		for(int i=0; i<(2-hexStr.length()); i++) {
			builder.append("0"); 
		}
		builder.append(hexStr.toUpperCase()); 
		
		return builder.toString(); 
	}
	
	public String getCode() {
		return code;
	}

	public String getCodeAsStr() {
		// 
		StringBuilder builder = new StringBuilder(); 
		builder.append(code);
		
		for(int i=0; i<(MaxCodeLenght-code.length()); i++) {
			builder.append(" "); 
		}
		
		return builder.toString(); 
	}
	
	public boolean isControlChar() {
		return controlChar;
	}
}