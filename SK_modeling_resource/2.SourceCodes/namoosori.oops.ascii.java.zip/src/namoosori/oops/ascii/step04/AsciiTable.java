/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */

package namoosori.oops.ascii.step04;

import java.util.ArrayList;
import java.util.List;

public class AsciiTable {
	//
	private AsciiModel model;
	private AsciiTableStyle tableStyle; 
	private List<AsciiColumn> asciiColumns; 
	
	public AsciiTable() {
		// 
		this.model = new AsciiModel(); 
		this.tableStyle = new AsciiTableStyle(); 
		this.asciiColumns = new ArrayList<>(); 
	}

	public void show() {
		//
		buildAsciiColumns(); 
		
		if (!tableStyle.isNoHeader()) {
			showInLine(composeHeader());
			showInLine("");
		}
		
		int rowIndex = 0; 
		while(rowIndex < tableStyle.getRowCount()) {
			showInLine(composeLine(rowIndex));
			rowIndex++; 
		}
	}
	
	private void showInLine(String message) {
		//
		System.out.println(message);
	}
	
	private String composeLine(int rowIndex) {
		// 
		int columnCount = tableStyle.getColumnCount(); 
		int rowCount = tableStyle.getRowCount(); 
		
		StringBuilder lineBuilder = new StringBuilder(); 
		lineBuilder.append(tableStyle.getSeparator()); 
		
		for(int i=0; i<columnCount; i++) {
			AsciiColumn asciiColumn = asciiColumns.get(i); 
			int targetIntValue = i*rowCount+rowIndex;
			lineBuilder.append(tableStyle.getColumnSpace()); 
			lineBuilder.append(asciiColumn.getAsciiStrOf(targetIntValue)); 
			lineBuilder.append(tableStyle.getColumnSpace()); 
			lineBuilder.append(tableStyle.getSeparator()); 
		}
		
		return lineBuilder.toString();
	}
	
	private String composeHeader() {
		// 
		int columnCount = tableStyle.getColumnCount(); 
		
		StringBuilder lineBuilder = new StringBuilder(); 
		lineBuilder.append(tableStyle.getSeparator()); 
		
		for(int i=0; i<columnCount; i++) {
			AsciiColumn asciiColumn = asciiColumns.get(i); 
			lineBuilder.append(tableStyle.getColumnSpace()); 
			lineBuilder.append(asciiColumn.getHeader()); 
			lineBuilder.append(tableStyle.getColumnSpace()); 
			lineBuilder.append(tableStyle.getSeparator()); 
		}
		
		return lineBuilder.toString();
	}
	
	public AsciiTableStyle getTableStyle() {
		return tableStyle; 
	}
	
	public AsciiCodeStyle getCodeStyle() {
		// 
		return tableStyle.getCodeStyle(); 
	}
	
	public void buildAsciiColumns() {
		// 
		int rowCount = tableStyle.getRowCount(); 
		int columnIndex = 0; 
		for(int i=0; i<AsciiCode.MaxIntValue; i++) {
			// 
			AsciiColumn asciiColumn = new AsciiColumn(columnIndex++, rowCount);
			asciiColumn.initWith(this.model, this.tableStyle.getCodeStyle());
			
			asciiColumns.add(asciiColumn); 
			i += rowCount; 
		}
	}
}