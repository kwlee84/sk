/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */

package namoosori.oops.ascii.step04;

public class AsciiTableStyle {
	//
	private static final int DefaultRowCount = 16;
	private static final String DefaultSeparator = "|"; 
	private static final int DefaultColumnSpace = 2; 
	
	private int rowCount; 
	private int columnSpaceCount; 
	private boolean noHeader; 
	private String separator; 
	
	private AsciiCodeStyle codeStyle;
	
	public AsciiTableStyle() {
		// 
		this(DefaultRowCount); 
	}
	
	public AsciiTableStyle(int rowCount) {
		// 
		this.noHeader = false; 
		this.separator = DefaultSeparator; 
		this.columnSpaceCount = DefaultColumnSpace; 
		this.rowCount = rowCount; 
		this.codeStyle = new AsciiCodeStyle(); 
	}
	
	public String getColumnSpace() {
		// 
		StringBuilder builder = new StringBuilder(); 
		for(int i=0; i<columnSpaceCount; i++) {
			builder.append(" "); 
		}
		
		return builder.toString(); 
	}
	
	public boolean isNoHeader() {
		// 
		return noHeader; 
	}
	
	public void setNoHeader(boolean noHeader) {
		// 
		this.noHeader = noHeader; 
	}
	
	public void setSeparator(String separator) {
		this.separator = separator; 
	}
	
	public String getSeparator() {
		return separator; 
	}
	
	public void setCustomRowCount(int rowCount) {
		// 
		this.rowCount = rowCount; 
	}
	
	public int getColumnCount() {
		//
		int columnCount = AsciiCode.MaxIntValue/rowCount;
		if (AsciiCode.MaxIntValue%rowCount > 0) {
			columnCount++; 
		}
		
		return columnCount; 
	}
	
	public AsciiCodeStyle getCodeStyle() {
		return codeStyle; 
	}
	
	public void setCustomeCodeStyle(AsciiCodeStyle codeStyle) {
		//
		this.codeStyle = codeStyle; 
	}
	
	public String getHeader() {
		// 
		return codeStyle.getCharHeader(); 
	}
	
	public int getRowCount() {
		return rowCount; 
	}
}