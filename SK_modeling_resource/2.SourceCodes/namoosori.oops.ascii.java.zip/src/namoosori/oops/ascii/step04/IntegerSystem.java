/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */

package namoosori.oops.ascii.step04;

public enum IntegerSystem {
		//
	Decimal("Dec", 3), 
	Binary(" Binary ", 8), 
	Octal("Oct", 3), 
	Hex("Hex ", 4),
	None("", 0); 

	String header;
	int length;

	private IntegerSystem(String header, int length) {
		//
		this.header = header;
		this.length = length;
	}

	public String getHeader() {
		return header;
	}

	public int getLength() {
		return length;
	}
}
