/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */

package namoosori.oops.ascii.step04;

import java.util.ArrayList;
import java.util.List;

public class AsciiCodeStyle {
	//
	private int spaceCount; 
	private String charHeader; 
	private List<IntegerSystem> intSystems; 
	
	public AsciiCodeStyle() {
		// 
		this.spaceCount = 2; 
		this.charHeader = "Char"; 
		this.intSystems = new ArrayList<>(); 
		this.include(IntegerSystem.Decimal).include(IntegerSystem.Binary).include(IntegerSystem.Octal).include(IntegerSystem.Hex); 
	}
	
	public String getHeader() {
		// 
		StringBuilder builder = new StringBuilder(); 
		for(IntegerSystem intSystem : intSystems) {
			builder.append(intSystem.getHeader()); 
			builder.append(space(spaceCount)); 
		}
		
		builder.append(charHeader); 
		return builder.toString(); 
	}

	public String format(AsciiCode asciiCode) {
		// 
		StringBuilder builder = new StringBuilder(); 
		for(IntegerSystem intSystem : intSystems) {
			builder.append(getAsciiIntStr(asciiCode, intSystem)); 
			builder.append(space(spaceCount)); 
		}
		
		builder.append(asciiCode.getCodeAsStr()); 
		return builder.toString(); 
	}
	
	public String formatForNone() {
		// 
		StringBuilder builder = new StringBuilder(); 
		for(IntegerSystem intSystem : intSystems) {
			builder.append((space(intSystem.getLength()))); 
			builder.append(space(spaceCount)); 
		}
		
		builder.append(space(AsciiCode.MaxCodeLenght)); 
		return builder.toString(); 
	}

	public AsciiCodeStyle clearIntSystem() {
		// 
		this.intSystems.clear(); 
		return this; 
	}
	
	public AsciiCodeStyle include(IntegerSystem intSystem) {
		// 
		this.intSystems.add(intSystem); 
		return this; 
	}
	
	public void setSpaceCount(int count) {
		// 
		this.spaceCount = count; 
	}
	
	private String space(int count) {
		// 
		StringBuilder builder = new StringBuilder(); 
		for(int i=0; i<count; i++) {
			builder.append(" "); 
		}
		
		return builder.toString(); 
	}
	
	private String getAsciiIntStr(AsciiCode asciiCode, IntegerSystem intSystem) {
		// 
		switch(intSystem) {
		case Decimal: 	return asciiCode.getIntValueAsStr(); 
		case Binary: 	return asciiCode.getIntValueAsBinaryStr(); 
		case Octal: 	return asciiCode.getIntValueAsOctalStr(); 
		case Hex: 		return asciiCode.getIntValueAsHexStr();
		case None: 		return "";
		}
		
		throw new RuntimeException("No such integer system --> " + intSystem.toString()); 
	}

	public String getCharHeader() {
		return charHeader;
	}

	public void setCharHeader(String charHeader) {
		this.charHeader = charHeader;
	}
}