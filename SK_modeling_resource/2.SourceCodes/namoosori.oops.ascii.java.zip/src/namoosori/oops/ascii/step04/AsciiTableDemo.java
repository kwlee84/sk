/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */

package namoosori.oops.ascii.step04;

public class AsciiTableDemo {
	//
	public static void main(String[] args) {
		// 
		// showDefaultAsciiTable(); 
		showAsciiCodeDisplayControl();
		// showTableControl(); 
	}
	
	private static void showDefaultAsciiTable() {
		// 
		AsciiTable asciiTable = new AsciiTable(); 
		asciiTable.show(); 
	}
	
	private static void showAsciiCodeDisplayControl() {
		// 
		AsciiTable asciiTable = new AsciiTable(); 
		AsciiCodeStyle codeStyle = asciiTable.getCodeStyle();  
		codeStyle.clearIntSystem().include(IntegerSystem.Hex).include(IntegerSystem.Decimal);   
		codeStyle.setCharHeader("Code");
		asciiTable.show(); 
	}

	private static void showTableControl() {
		// 
		AsciiTable asciiTable = new AsciiTable();
		asciiTable.getTableStyle().setCustomRowCount(20);
		asciiTable.getTableStyle().setNoHeader(true);
		asciiTable.getTableStyle().setSeparator("|");
		asciiTable.show(); 
	}
} 