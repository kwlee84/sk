/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */

package namoosori.oops.ascii.step02;

public class AsciiTable {
	//
	private AsciiModel model; 
	
	public AsciiTable() {
		// 
		this.model = new AsciiModel(); 
	}
	
	public void showAsBaseFormat() {
		//
		int count = model.countCode(); 
		System.out.println("Dec   Binaray    Oct   Hex     Char");
		System.out.println("...................................");

		for(int index=0; index<count; index++) {
			// 
			AsciiCode asciiCode = model.requestCode(index); 
			System.out.println(
					String.format("%s   %s   %s   %s    %s", 
							asciiCode.getIndexAsStr(), 
							asciiCode.getIndexAsBinaryStr(),
							asciiCode.getIndexAsOctalStr(), 
							asciiCode.getIndexAsHexStr(),
							asciiCode.getCode()));
		}
	}
}