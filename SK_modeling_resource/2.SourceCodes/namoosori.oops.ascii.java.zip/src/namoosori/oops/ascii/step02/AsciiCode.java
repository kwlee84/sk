/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */

package namoosori.oops.ascii.step02;

public class AsciiCode {
	//
	public static final int ControlIndex = 32; 
	public static final int MaxIndex = 127; 
	
	private byte index; 
	private String code; 
	private boolean controlChar; 
	
	public AsciiCode(int index, String code) {
		// 
		if (index > MaxIndex) {
			throw new RuntimeException("Index shoud be under " + MaxIndex); 
		}
		
		this.index = (byte)index; 
		this.code = code; 
		
		if (index <ControlIndex || index == MaxIndex) {
			this.controlChar = true; 
		} else {
			this.controlChar = false; 
		}
	}
	
	public int getIndex() {
		return (int)index;
	}

	public String getIndexAsStr() {
		// 
		return String.format("%03d", index); 
	}
	
	public String getIndexAsBinaryStr() {
		// 
		String binaryStr = Integer.toBinaryString(index); 
		
		StringBuilder builder = new StringBuilder(); 
		for(int i=0; i<(8-binaryStr.length()); i++) {
			builder.append("0"); 
		}
		builder.append(binaryStr); 
		
		return builder.toString(); 
	}
	
	public String getIndexAsOctalStr() {
		//
		String octalStr = Integer.toOctalString(index); 
		
		StringBuilder builder = new StringBuilder(); 
		for(int i=0; i<(3-octalStr.length()); i++) {
			builder.append("0"); 
		}
		builder.append(octalStr); 
		
		return builder.toString(); 
	}
	
	public String getIndexAsHexStr() {
		//
		String hexStr = Integer.toHexString(index); 
		
		StringBuilder builder = new StringBuilder(); 
		builder.append("0X"); 
		for(int i=0; i<(2-hexStr.length()); i++) {
			builder.append("0"); 
		}
		builder.append(hexStr.toUpperCase()); 
		
		return builder.toString(); 
	}
	
	public String getCode() {
		return code;
	}

	public boolean isControlChar() {
		return controlChar;
	}
}