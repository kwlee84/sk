/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */

package namoosori.oops.ascii.step03;

import namoosori.oops.ascii.step03.AsciiCodeStyle.IntSystem;

public class AsciiTable {
	//
	private AsciiModel model; 
	private AsciiCodeStyle codeStyle;
	
	public AsciiTable() {
		// 
		this.model = new AsciiModel(); 
		this.codeStyle = new AsciiCodeStyle(); 
	}
	
	public void showAsDefaultFormat() {
		//
		int count = model.countCode(); 
		System.out.println("Dec   Binaray    Oct   Hex     Char");
		System.out.println("...................................");
		
		for(int index=0; index<count; index++) {
			// 
			AsciiCode asciiCode = model.requestCode(index); 
			System.out.println(codeStyle.format(asciiCode));
		}
	}
	
	public void showAsCustomFormat() {
		//
		int count = model.countCode(); 
		System.out.println("Binaray   Oct  Char");
		System.out.println("...................");

		codeStyle.include(IntSystem.Binary).include(IntSystem.Octal); 
		
		for(int index=0; index<count; index++) {
			// 
			AsciiCode asciiCode = model.requestCode(index); 
			System.out.println(codeStyle.format(asciiCode));
		}
	}
}