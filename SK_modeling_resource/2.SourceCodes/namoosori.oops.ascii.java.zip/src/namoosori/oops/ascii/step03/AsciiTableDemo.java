/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */

package namoosori.oops.ascii.step03;

public class AsciiTableDemo {
	//
	public static void main(String[] args) {
		// 
		showDefaultAsciiTable(); 
	}
	
	private static void showDefaultAsciiTable() {
		// 
		AsciiTable asciiTable = new AsciiTable(); 
		//asciiTable.showAsDefaultFormat(); 
		asciiTable.showAsCustomFormat(); 
	}
}