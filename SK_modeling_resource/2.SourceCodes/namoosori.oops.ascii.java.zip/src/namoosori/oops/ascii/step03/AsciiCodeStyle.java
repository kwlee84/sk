/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */

package namoosori.oops.ascii.step03;

import java.util.ArrayList;
import java.util.List;

public class AsciiCodeStyle {
	//
	private int spaceCount; 
	private boolean customIntSystem; 
	private List<IntSystem> intSystems; 
	
	public AsciiCodeStyle() {
		// 
		this.spaceCount = 2; 
		this.customIntSystem = false; 
		this.intSystems = new ArrayList<>(); 
		this.intSystems.add(IntSystem.Decimal); 
		this.intSystems.add(IntSystem.Binary); 
		this.intSystems.add(IntSystem.Octal); 
		this.intSystems.add(IntSystem.Hex); 
	}
	
	public String format(AsciiCode asciiCode) {
		// 
		StringBuilder builder = new StringBuilder(); 
		for(IntSystem intSystem : intSystems) {
			builder.append(getAsciiIntStr(asciiCode, intSystem)); 
			builder.append(space(spaceCount)); 
		}
		
		builder.append(asciiCode.getCode()); 
		return builder.toString(); 
	}
	
	public AsciiCodeStyle include(IntSystem intSystem) {
		// 
		if(!customIntSystem) {
			this.intSystems.clear();
			this.customIntSystem = true; 
		}
		
		this.intSystems.add(intSystem); 
		
		return this; 
	}
	
	public void setSpaceCount(int count) {
		// 
		this.spaceCount = count; 
	}
	
	private String space(int count) {
		// 
		StringBuilder builder = new StringBuilder(); 
		for(int i=0; i<count; i++) {
			builder.append(" "); 
		}
		
		return builder.toString(); 
	}
	
	private String getAsciiIntStr(AsciiCode asciiCode, IntSystem intSystem) {
		// 
		switch(intSystem) {
		case Decimal: 	return asciiCode.getIndexAsStr(); 
		case Binary: 	return asciiCode.getIndexAsBinaryStr(); 
		case Octal: 	return asciiCode.getIndexAsOctalStr(); 
		case Hex: 		return asciiCode.getIndexAsHexStr();
		default: throw new RuntimeException("No such integer system --> " + intSystem.toString()); 
		}
	}
	
	enum IntSystem {
		Decimal, 
		Binary, 
		Octal, 
		Hex
	}
}