/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */

package namoosori.oops.timestable.level3;

import java.util.ArrayList;
import java.util.List;

public class TimesTableStory3 {
	//
	public static void main(String[] args) {
		//
		showBoxTableWithObjectDemo();
		showBoxTableWithProcedureDemo();
	}

	private static void showBoxTableWithObjectDemo() {
		//
		TimesTable timesTable = new TimesTable(); 
		
		timesTable.addTable(new BoxTable(3, DisplayStyle.InKorean)); 
		timesTable.addTable(new BoxTable(5, DisplayStyle.InEnglish)); 
		timesTable.addTable(new BoxTable(7, DisplayStyle.InExpression)); 
		timesTable.addTable(new BoxTable(9));
		
		timesTable.setColumn(3);
		timesTable.show(); 
		
		timesTable.clear(); 
		for(int leftNumber = 2; leftNumber <= 9; leftNumber++) {
			timesTable.addTable(new BoxTable(leftNumber, DisplayStyle.InKorean)); 
		}
		
		timesTable.setColumn(5);
		timesTable.show(); 
	}

	private static void showBoxTableWithProcedureDemo() {
		//
		List<BoxTable> timesTables = new ArrayList<BoxTable>(); 
		timesTables.add(new BoxTable(3, DisplayStyle.InKorean)); 
		timesTables.add(new BoxTable(5, DisplayStyle.InEnglish)); 
		timesTables.add(new BoxTable(7, DisplayStyle.InExpression)); 
		timesTables.add(new BoxTable(9));
		
		BoxAligner boxAligner = new BoxAligner(); 
		boxAligner.setColumn(3);
		boxAligner.show(timesTables);
		
		timesTables.clear(); 
		for(int leftNumber = 2; leftNumber <= 9; leftNumber++) {
			timesTables.add(new BoxTable(leftNumber, DisplayStyle.InKorean)); 
		}
		
		boxAligner.setColumn(5);
		boxAligner.show(timesTables);
	}
} 