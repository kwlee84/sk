/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */

package namoosori.oops.timestable.level0;

public class TimesTableStory {
	//
	public static void main(String[] args) {
		// 
		System.out.println("Let's print out the multiplication tables."); 
		System.out.println("-----------------"); 

		int leftNumber = 2; 
		System.out.println(leftNumber + " times " + 1 + " = " + (leftNumber*1));
		System.out.println(leftNumber + " times " + 2 + " = " + (leftNumber*1));
		System.out.println(leftNumber + " times " + 3 + " = " + (leftNumber*1));
		System.out.println(leftNumber + " times " + 4 + " = " + (leftNumber*1));
		System.out.println(leftNumber + " times " + 5 + " = " + (leftNumber*1));
		System.out.println(leftNumber + " times " + 6 + " = " + (leftNumber*1));
		System.out.println(leftNumber + " times " + 7 + " = " + (leftNumber*1));
		System.out.println(leftNumber + " times " + 8 + " = " + (leftNumber*1));
		System.out.println(leftNumber + " times " + 9 + " = " + (leftNumber*1));
		System.out.println("-------------------------------------------------");

		leftNumber = 3; 
		System.out.println(leftNumber + " times " + 1 + " = " + (leftNumber*1));
		System.out.println(leftNumber + " times " + 2 + " = " + (leftNumber*1));
		System.out.println(leftNumber + " times " + 3 + " = " + (leftNumber*1));
		System.out.println(leftNumber + " times " + 4 + " = " + (leftNumber*1));
		System.out.println(leftNumber + " times " + 5 + " = " + (leftNumber*1));
		System.out.println(leftNumber + " times " + 6 + " = " + (leftNumber*1));
		System.out.println(leftNumber + " times " + 7 + " = " + (leftNumber*1));
		System.out.println(leftNumber + " times " + 8 + " = " + (leftNumber*1));
		System.out.println(leftNumber + " times " + 9 + " = " + (leftNumber*1));
		System.out.println("-------------------------------------------------");
		
		leftNumber = 4; 
		System.out.println(leftNumber + " times " + 1 + " = " + (leftNumber*1));
		System.out.println(leftNumber + " times " + 2 + " = " + (leftNumber*1));
		System.out.println(leftNumber + " times " + 3 + " = " + (leftNumber*1));
		System.out.println(leftNumber + " times " + 4 + " = " + (leftNumber*1));
		System.out.println(leftNumber + " times " + 5 + " = " + (leftNumber*1));
		System.out.println(leftNumber + " times " + 6 + " = " + (leftNumber*1));
		System.out.println(leftNumber + " times " + 7 + " = " + (leftNumber*1));
		System.out.println(leftNumber + " times " + 8 + " = " + (leftNumber*1));
		System.out.println(leftNumber + " times " + 9 + " = " + (leftNumber*1));
		System.out.println("-------------------------------------------------");
	}
}