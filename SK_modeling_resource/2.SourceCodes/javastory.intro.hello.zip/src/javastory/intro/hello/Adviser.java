/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */

package javastory.intro.hello;

public class Adviser {
	//
	private Student student; 
	
	public Adviser() {
		// 
	}
	
	public void sayHelloToStudent() {
		// 
		if (!hasAsignedStudent()) {
			System.out.println("Adviser: Sorry, I have no student to say hello."); 
			return; 
		}
		
		System.out.println("Adviser: " + student.getName() + ", Welcome to object-full Java world!"); 
		System.out.println("       : " + "How are you feeling today?"); 
		
		student.tellMeYourFeeling();
	}
	
	private boolean hasAsignedStudent() {
		//
		if(student != null) {
			return true; 
		}
		
		return false; 
	}
	
	public void asignStudent(Student student) {
		this.student = student; 
	}
}