/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */

package javastory.intro.hello;

public class StoryAssistant {
	//
	public static void main(String[] args) {
		// 
		tellMeSayHelloStory();
	}

	private static void tellMeSayHelloStory() {
		// 
		String yourName = "Hanseol"; 
		Student student = inviteStudent(yourName); 
		Adviser adviser = inviteAdviser(); 
		adviser.asignStudent(student);
		
		adviser.sayHelloToStudent(); 
	}
	
	private static Student inviteStudent(String yourName) {
		// 
		Student student = new Student(yourName); 
		return student; 
	}
	
	private static Adviser inviteAdviser() {
		// 
		Adviser adviser = new Adviser(); 
		return adviser; 
	}
}